package com.nik.mylivewallpaper;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int PICK_VIDEO = 41;
    private TextView selected;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(28, 36, 28, 36);
        layout.setBackgroundColor(0xFF101820);

        TextView title = new TextView(this);
        title.setText("MY LIVE WALLPAPER"); title.setTextColor(0xFFFFFFFF);
        title.setTextSize(24); title.setGravity(Gravity.CENTER); title.setPadding(0,0,0,18);
        layout.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView description = new TextView(this);
        description.setText("Choose any video saved on your phone. The app remembers your choice, plays it silently in a loop, and opens Android's wallpaper preview.");
        description.setTextColor(0xFFE5E7EB); description.setTextSize(16); description.setGravity(Gravity.CENTER); description.setPadding(0,0,0,20);
        layout.addView(description, new LinearLayout.LayoutParams(-1, -2));

        selected = new TextView(this);
        selected.setTextColor(0xFFB8C0CC); selected.setTextSize(14); selected.setGravity(Gravity.CENTER); selected.setPadding(0,0,0,18);
        layout.addView(selected, new LinearLayout.LayoutParams(-1, -2));
        refreshSelected();

        Button choose = new Button(this); choose.setText("CHOOSE / CHANGE VIDEO");
        choose.setOnClickListener(v -> { Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("video/*"); i.addCategory(Intent.CATEGORY_OPENABLE); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION); startActivityForResult(i, PICK_VIDEO); });
        layout.addView(choose, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        Button apply = new Button(this); apply.setText("PREVIEW & SET WALLPAPER");
        apply.setOnClickListener(v -> {
            String uri = getPreferences(MODE_PRIVATE).getString("video_uri", null);
            if (uri == null) { Toast.makeText(this, "First tap CHOOSE / CHANGE VIDEO", Toast.LENGTH_LONG).show(); return; }
            try { Intent i = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER); i.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, new ComponentName(this, VideoWallpaperService.class)); startActivity(i); }
            catch (Exception e) { Toast.makeText(this, "Open Wallpaper settings and select My Live Wallpaper", Toast.LENGTH_LONG).show(); }
        });
        layout.addView(apply, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView note = new TextView(this);
        note.setText("Video audio is muted. Long or high-resolution videos can use more battery. Lock-screen availability depends on your phone's software.");
        note.setTextColor(0xFFB8C0CC); note.setTextSize(13); note.setGravity(Gravity.CENTER); note.setPadding(0,24,0,0);
        layout.addView(note, new LinearLayout.LayoutParams(-1, -2));
        setContentView(layout);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_VIDEO && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (SecurityException ignored) {}
            getPreferences(MODE_PRIVATE).edit().putString("video_uri", uri.toString()).apply();
            refreshSelected(); Toast.makeText(this, "Video selected. Tap PREVIEW & SET WALLPAPER.", Toast.LENGTH_LONG).show();
        }
    }
    private void refreshSelected() {
        String uri = getPreferences(MODE_PRIVATE).getString("video_uri", null);
        selected.setText(uri == null ? "No video selected yet" : "A video is selected. Tap below to choose a different one any time.");
    }
}
