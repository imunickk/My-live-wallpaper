package com.nik.mylivewallpaper;

import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;
import android.media.MediaPlayer;
import android.net.Uri;
import android.content.SharedPreferences;
import java.io.IOException;

public class VideoWallpaperService extends WallpaperService {
    @Override public Engine onCreateEngine() { return new VideoEngine(); }

    private class VideoEngine extends Engine implements SurfaceHolder.Callback {
        private MediaPlayer player;
        private boolean visible;
        private boolean surfaceReady;
        VideoEngine() { getSurfaceHolder().addCallback(this); }

        @Override public void onVisibilityChanged(boolean isVisible) { visible = isVisible; if (visible) startPlayer(); else pausePlayer(); }
        @Override public void onSurfaceCreated(SurfaceHolder holder) { surfaceReady = true; startPlayer(); }
        @Override public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) { if (player != null) player.setDisplay(holder); }
        @Override public void onSurfaceDestroyed(SurfaceHolder holder) { surfaceReady = false; releasePlayer(); }

        private void startPlayer() {
            if (!visible || !surfaceReady || player != null) return;
            String chosen = getSharedPreferences("MyLiveWallpaper", MODE_PRIVATE).getString("video_uri", null);
            // MainActivity uses Activity preferences, which are named with its default preference file; use that same file name below.
            chosen = getSharedPreferences("MainActivity", MODE_PRIVATE).getString("video_uri", chosen);
            if (chosen == null) return;
            try {
                player = new MediaPlayer();
                player.setDataSource(VideoWallpaperService.this, Uri.parse(chosen));
                player.setSurface(getSurfaceHolder().getSurface()); player.setLooping(true); player.setVolume(0f, 0f);
                player.setOnPreparedListener(mp -> { if (player == mp && visible && surfaceReady) mp.start(); });
                player.setOnErrorListener((mp, what, extra) -> { releasePlayer(); return true; });
                player.prepareAsync();
            } catch (IOException | IllegalStateException e) { releasePlayer(); }
        }
        private void pausePlayer() { if (player != null) { try { if (player.isPlaying()) player.pause(); } catch (IllegalStateException ignored) {} } }
        private void releasePlayer() { if (player != null) { try { player.setOnPreparedListener(null); player.setOnErrorListener(null); player.reset(); player.release(); } catch (IllegalStateException ignored) {} player = null; } }
        @Override public void onDestroy() { releasePlayer(); super.onDestroy(); }
    }
}
