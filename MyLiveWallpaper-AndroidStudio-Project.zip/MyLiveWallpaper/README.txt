MY LIVE WALLPAPER - ANDROID PROJECT

What this app does:
- Lets you choose any video from your phone using Android's file picker.
- Remembers the selected video, so you can change it whenever you want.
- Plays the selected video silently in a loop as an Android live wallpaper.
- Opens Android's live wallpaper preview/apply screen.

Important limitations:
- This ZIP is Android source code, NOT an installable APK.
- The project must be compiled with Android build tools before installation.
- Live wallpaper support on the lock screen depends on the phone manufacturer/software.
- Some video formats/codecs may not play. Use a standard MP4 (H.264) for best compatibility.
- Long/high-resolution videos can use more battery.

No paid services are required by the app itself. The app does not request internet permission.

Package: com.nik.mylivewallpaper
